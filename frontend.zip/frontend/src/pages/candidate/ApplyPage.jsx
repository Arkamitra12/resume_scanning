
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { submitApplication } from "../../services/api";

function ApplyPage() {
  const { jobId } = useParams();
  const navigate = useNavigate();

  const [resume, setResume] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!resume) {
      setError("Please upload your resume.");
      return;
    }

    setLoading(true);

    try {
      await submitApplication(jobId, resume);
      setSubmitted(true);
    } catch (err) {
      setError(err.message || "Application submission failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleResumeChange = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    if (file.type !== "application/pdf") {
      setError("Please upload a PDF resume.");
      e.target.value = "";
      setResume(null);
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError("Resume size must be less than 5 MB.");
      e.target.value = "";
      setResume(null);
      return;
    }

    setError("");
    setResume(file);
  };

  if (submitted) {
    return (
      <div className="login-page">
        <div className="login-card">
          <div className="login-logo">✦ HireAI</div>

          <h1>Application Submitted!</h1>

          <p className="login-subtitle">
            Your application has been submitted successfully.
            We look forward to reviewing your profile.
          </p>

          <button
            className="login-submit-button"
            onClick={() => navigate("/candidate/jobs")}
          >
            Browse More Jobs
          </button>

          <button
            className="login-back-button"
            onClick={() => navigate("/candidate/applications")}
          >
            View My Applications
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="apply-page">
      <div className="apply-card">
        <h1>Apply for Job</h1>

        <p className="apply-subtitle">
          Upload your resume to submit your application.
        </p>

        <form onSubmit={handleSubmit}>
          <div className="apply-input-group">
            <label>Upload Resume (PDF)</label>

            <div className="resume-upload-box">
              <input
                type="file"
                accept=".pdf,application/pdf"
                onChange={handleResumeChange}
                required
              />

              <p>Accepted format: PDF</p>
              <p>Maximum file size: 5 MB</p>
            </div>

            {resume && (
              <p className="resume-file-name">
                <span>✓</span> {resume.name}
              </p>
            )}
          </div>

          {error && <p style={{ color: "red" }}>{error}</p>}

          <button
            type="submit"
            className="apply-submit-button"
            disabled={loading}
          >
            {loading ? "Submitting Application..." : "Submit Application"}
          </button>

          <button
            type="button"
            className="apply-cancel-button"
            onClick={() => navigate(`/candidate/jobs/${jobId}`)}
          >
            Cancel
          </button>
        </form>
      </div>
    </div>
  );
}

export default ApplyPage;
