
import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { getJobById } from "../../services/api";

function JobDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchJob = async () => {
      try {
        const data = await getJobById(id);
        setJob(data.job || data);
      } catch (err) {
        setError(err.message || "Unable to load job details.");
      } finally {
        setLoading(false);
      }
    };

    fetchJob();
  }, [id]);

  if (loading) {
    return <div className="candidate-job-details-page"><h2>Loading job details...</h2></div>;
  }

  if (error || !job) {
    return (
      <div className="candidate-job-details-page">
        <h2>{error || "Job not found"}</h2>
        <button onClick={() => navigate("/candidate/jobs")}>
          ← Back to Jobs
        </button>
      </div>
    );
  }

  const skills = job.required_skills || job.skills || [];
  const jobId = job.job_id || job.id;

  return (
    <div className="candidate-job-details-page">
      <button
        className="candidate-back-button"
        onClick={() => navigate("/candidate/jobs")}
      >
        ← Back to Jobs
      </button>

      <div className="candidate-job-details-card">
        <div className="candidate-job-details-header">
          <div>
            <h1>{job.title}</h1>
            <p>{job.department || "General"}</p>
          </div>

          <span className="candidate-job-type">
            {job.type || job.employment_type || "Job"}
          </span>
        </div>

        <div className="candidate-job-meta">
          <span>📍 {job.location || "Not specified"}</span>
          <span>💼 {job.type || job.employment_type || "Job"}</span>
        </div>

        <hr />

        <h2>Job Description</h2>
        <p className="candidate-job-details-description">
          {job.description || "No description available."}
        </p>

        <h2>Required Skills</h2>

        <div className="candidate-job-skills">
          {skills.map((skill, index) => (
            <span key={index}>{skill}</span>
          ))}
        </div>

        <button
          className="candidate-apply-button"
          onClick={() => navigate(`/candidate/apply/${jobId}`)}
        >
          Apply for this Job
        </button>
      </div>
    </div>
  );
}

export default JobDetailsPage;
