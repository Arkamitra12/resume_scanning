import { useState, useEffect } from "react";
import { getMyApplications } from "../../services/api";

function MyApplicationsPage() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchApplications();
  }, []);

  async function fetchApplications() {
    try {
      setLoading(true);
      setError("");

      const data = await getMyApplications();
      setApplications(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err.message || "Failed to load applications.");
    } finally {
      setLoading(false);
    }
  }

  const getStatusClass = (status) => {
    if (status === "reviewed") return "status-review";
    if (status === "screened") return "status-shortlisted";
    if (status === "screening_failed") return "status-rejected";
    return "status-applied";
  };

  const getDecisionLabel = (decision) => {
    switch (decision) {
      case "proceed":
        return "Proceed";
      case "hold":
        return "On Hold";
      case "do_not_proceed":
        return "Do Not Proceed";
      default:
        return "Pending";
    }
  };

  if (loading) {
    return <div className="my-applications-page"><h1>Loading applications...</h1></div>;
  }

  if (error) {
    return <div className="my-applications-page"><p className="form-error">{error}</p></div>;
  }

  const reviewedCount = applications.filter(
    (a) => a.application_status === "reviewed"
  ).length;

  const screenedCount = applications.filter(
    (a) => a.application_status === "screened"
  ).length;

  return (
    <div className="my-applications-page">
      <div className="applications-header">
        <h1>My Applications</h1>
        <p>Track the progress of your job applications.</p>
      </div>

      <div className="applications-summary">
        <div className="application-summary-card">
          <h3>Total Applications</h3>
          <h2>{applications.length}</h2>
        </div>

        <div className="application-summary-card">
          <h3>AI Screened</h3>
          <h2>{screenedCount}</h2>
        </div>

        <div className="application-summary-card">
          <h3>Reviewed</h3>
          <h2>{reviewedCount}</h2>
        </div>
      </div>

      <div className="applications-table-card">
        <h2>Application History</h2>

        {applications.length === 0 ? (
          <p>No applications found.</p>
        ) : (
          <div className="applications-table-wrapper">
            <table className="applications-table">
              <thead>
                <tr>
                  <th>Application ID</th>
                  <th>Status</th>
                  <th>Recruiter Decision</th>
                  <th>Reviewed On</th>
                </tr>
              </thead>

              <tbody>
                {applications.map((application) => (
                  <tr key={application.application_id}>
                    <td>{application.application_id}</td>

                    <td>
                      <span
                        className={`application-status ${getStatusClass(
                          application.application_status
                        )}`}
                      >
                        {application.application_status?.replace(/_/g, " ") || "Unknown"}
                      </span>
                    </td>

                    <td>
                      {getDecisionLabel(application.final_decision)}
                    </td>

                    <td>
                      {application.reviewed_at
                        ? new Date(application.reviewed_at).toLocaleDateString()
                        : "Not reviewed"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default MyApplicationsPage;