
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getJobs } from "../../services/api";

function CandidateJobsPage() {
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const data = await getJobs();
        setJobs(Array.isArray(data) ? data : data.jobs || []);
      } catch (err) {
        setError(err.message || "Unable to load jobs.");
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  const filteredJobs = jobs.filter((job) =>
    `${job.title || ""} ${job.department || ""} ${job.location || ""}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div className="candidate-jobs-page">
      <div className="candidate-jobs-header">
        <h1>Explore Opportunities</h1>
        <p>Find the right job and take the next step in your career.</p>
      </div>

      <div className="candidate-search-box">
        <input
          type="text"
          placeholder="Search by job title, department or location..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="candidate-jobs-list">
        <div className="candidate-jobs-heading">
          <h2>Available Jobs</h2>
          <span>{filteredJobs.length} jobs found</span>
        </div>

        {loading ? (
          <div className="candidate-no-jobs">
            <p>Loading jobs...</p>
          </div>
        ) : error ? (
          <div className="candidate-no-jobs">
            <h3>Unable to load jobs</h3>
            <p>{error}</p>
          </div>
        ) : filteredJobs.length === 0 ? (
          <div className="candidate-no-jobs">
            <h3>No jobs found</h3>
            <p>Try searching with a different keyword.</p>
          </div>
        ) : (
          filteredJobs.map((job) => {
            const skills = job.required_skills || job.skills || [];

            return (
              <div className="candidate-job-card" key={job.job_id || job.id}>
                <div className="candidate-job-card-top">
                  <div>
                    <h3>{job.title}</h3>
                    <p className="candidate-job-department">
                      {job.department || "General"}
                    </p>
                  </div>

                  <span className="candidate-job-type">
                    {job.type || job.employment_type || "Job"}
                  </span>
                </div>

                <div className="candidate-job-meta">
                  <span>📍 {job.location || "Not specified"}</span>
                  <span>💼 {job.type || job.employment_type || "Job"}</span>
                </div>

                <p className="candidate-job-description">
                  {job.description || "No job description available."}
                </p>

                <div className="candidate-job-skills">
                  {skills.map((skill, index) => (
                    <span key={index}>{skill}</span>
                  ))}
                </div>

                <button
                  className="candidate-view-job-button"
                  onClick={() =>
                    navigate(`/candidate/jobs/${job.job_id || job.id}`)
                  }
                >
                  View Details →
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

export default CandidateJobsPage;
