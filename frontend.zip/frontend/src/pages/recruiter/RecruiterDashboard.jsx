
import React, { useEffect, useState } from "react";
import { getJobs, getAllApplications, default as apiRequest } from "../../services/api";

const RecruitDashboard = () => {
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [screeningScores, setScreeningScores] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        setError("");

        const [jobsData, applicationsData] = await Promise.all([
          getJobs(),
          getAllApplications(),
        ]);

        const safeJobs = Array.isArray(jobsData) ? jobsData : [];
        const safeApplications = Array.isArray(applicationsData)
          ? applicationsData
          : [];

        setJobs(safeJobs);
        setApplications(safeApplications);

        // Fetch screening results for applications
        const scoreResults = await Promise.all(
          safeApplications.map(async (application) => {
            try {
              const result = await apiRequest(
                `/applications/${application.application_id}/screening`
              );

              return {
                application_id: application.application_id,
                score: result.match_percentage,
              };
            } catch {
              return {
                application_id: application.application_id,
                score: null,
              };
            }
          })
        );

        const scoreMap = {};

        scoreResults.forEach((result) => {
          scoreMap[result.application_id] = result.score;
        });

        setScreeningScores(scoreMap);
      } catch (err) {
        setError(err.message || "Failed to load dashboard data.");
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const totalJobs = jobs.length;

  const totalApplications = applications.length;

  const pendingReviews = applications.filter(
    (application) => application.status === "submitted"
  ).length;

  const aiScreened = applications.filter(
    (application) =>
      application.status === "screened" ||
      application.status === "reviewed"
  ).length;

  const reviewedApplications = applications.filter(
    (application) => application.status === "reviewed"
  ).length;

  const validScores = Object.values(screeningScores).filter(
    (score) => typeof score === "number"
  );

  const averageScore =
    validScores.length > 0
      ? Math.round(
          validScores.reduce((total, score) => total + score, 0) /
            validScores.length
        )
      : 0;

  const recentApplications = [...applications]
    .sort(
      (a, b) =>
        new Date(b.submitted_at) - new Date(a.submitted_at)
    )
    .slice(0, 5);

  const stats = [
    {
      title: "Total Job Openings",
      value: totalJobs,
      description: "Currently available positions",
      icon: "💼",
    },
    {
      title: "Total Applications",
      value: totalApplications,
      description: "Candidates have applied",
      icon: "📄",
    },
    {
      title: "Pending Reviews",
      value: pendingReviews,
      description: "Awaiting AI screening",
      icon: "⏳",
    },
    {
      title: "AI Screened",
      value: aiScreened,
      description: "Screening completed",
      icon: "🤖",
    },
    {
      title: "Reviewed Applications",
      value: reviewedApplications,
      description: "Recruiter decisions recorded",
      icon: "👤",
    },
    {
      title: "Average AI Match Score",
      value: `${averageScore}%`,
      description: "Average of available screening scores",
      icon: "📊",
    },
  ];

  if (loading) {
    return (
      <div className="dashboard-page">
        <h1>Recruiter Dashboard</h1>
        <p>Loading dashboard data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-page">
        <h1>Recruiter Dashboard</h1>
        <p className="error-message">{error}</p>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <div className="dashboard-header">
        <h1>Recruiter Dashboard</h1>
        <p>Overview of your recruitment activity</p>
      </div>

      <div className="stats-grid">
        {stats.map((stat, index) => (
          <div className="stat-card" key={index}>
            <div className="stat-icon">{stat.icon}</div>
            <h3>{stat.title}</h3>
            <h2>{stat.value}</h2>
            <p>{stat.description}</p>
          </div>
        ))}
      </div>

      <div className="recent-applications">
        <h2>Recent Applications</h2>

        {recentApplications.length === 0 ? (
          <p>No applications received yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Application ID</th>
                <th>Job ID</th>
                <th>Applied On</th>
                <th>AI Score</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              {recentApplications.map((application) => (
                <tr key={application.application_id}>
                  <td>{application.application_id}</td>
                  <td>{application.job_id}</td>
                  <td>
                    {application.submitted_at
                      ? new Date(application.submitted_at).toLocaleDateString()
                      : "N/A"}
                  </td>
                  <td>
                    {typeof screeningScores[application.application_id] ===
                    "number"
                      ? `${screeningScores[application.application_id]}%`
                      : "Not screened"}
                  </td>
                  <td>
                    <span
                      className={`status ${application.status
                        ?.replace(/_/g, "-")
                        .toLowerCase()}`}
                    >
                      {application.status?.replace(/_/g, " ")}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default RecruitDashboard;
