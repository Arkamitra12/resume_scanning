
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { loginUser } from "../services/api";

function LoginPage() {
  const { role } = useParams();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const isCandidate = role === "candidate";
  const roleTitle = isCandidate ? "Candidate" : "Recruiter";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const data = await loginUser({
        email,
        password,
      });

      // Save authentication token
      const token = data.access_token || data.token;
      if (token) {
        localStorage.setItem("token", token);
      }

      // Save user information
      // Save user information
const user = data.user || data;
localStorage.setItem("user", JSON.stringify(user));

const actualRole = String(user.role || user.user_role || "").toLowerCase();

console.log("Login response:", data);
console.log("Actual role:", actualRole);
console.log("Login page role:", role);

if (actualRole !== role) {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  setError(`This account is not registered as a ${role}.`);
  return;
}

if (actualRole === "candidate") {
  navigate("/candidate/jobs");
} else if (actualRole === "recruiter") {
  navigate("/recruiter");
} else {
  setError("Unable to determine user role.");
}
    } catch (err) {
      setError(err.message || "Login failed. Please check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo">✦ HireAI</div>

        <h1>{roleTitle} Login</h1>

        <p className="login-subtitle">
          Welcome back! Please login to continue.
        </p>

        <form onSubmit={handleSubmit}>
          <div className="login-input-group">
            <label>Email Address</label>
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="login-input-group">
            <label>Password</label>
            <input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && (
            <p style={{ color: "red" }}>{error}</p>
          )}

          <button
            type="submit"
            className="login-submit-button"
            disabled={loading}
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <p className="login-register-text">
          Don't have an account?{" "}
          <span onClick={() => navigate(`/${role}/register`)}>
            Register
          </span>
        </p>

        <button
          className="login-back-button"
          onClick={() => navigate("/")}
        >
          ← Back to Home
        </button>
      </div>
    </div>
  );
}

export default LoginPage;
