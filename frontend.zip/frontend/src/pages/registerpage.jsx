import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { registerCandidate } from "../services/api";

function RegisterPage() {
  const { role } = useParams();
  const navigate = useNavigate();

  const isCandidate = role === "candidate";
  const roleTitle = isCandidate ? "Candidate" : "Recruiter";

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [registered, setRegistered] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (password.length < 8) {
      setError("Password must contain at least 8 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Your passwords do not match. Please try again.");
      return;
    }

    if (!isCandidate) {
      setError("Recruiter registration is not currently available.");
      return;
    }

    setLoading(true);

    try {
      await registerCandidate({
        name: name.trim(),
        email: email.trim(),
        password,
      });

      setRegistered(true);
    } catch (err) {
      setError(err.message || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const clearError = () => {
    if (error) setError("");
  };

  return (
    <div className="login-page">
      {registered ? (
        <div className="login-card">
          <div className="login-logo">✦ HireAI</div>

          <h1>Registration Successful!</h1>

          <p className="login-subtitle">
            Your {roleTitle} registration has been completed successfully.
          </p>

          <button
            className="login-submit-button"
            onClick={() => navigate(`/${role}/login`)}
          >
            Go to Login
          </button>

          <button
            className="login-back-button"
            onClick={() => navigate("/")}
          >
            ← Back to Home
          </button>
        </div>
      ) : (
        <div className="login-card">
          <div className="login-logo">✦ HireAI</div>

          <h1>{roleTitle} Registration</h1>

          <p className="login-subtitle">
            Create your account to get started.
          </p>

          <form onSubmit={handleSubmit}>
            <div className="login-input-group">
              <label>Full Name</label>
              <input
                type="text"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  clearError();
                }}
                required
              />
            </div>

            <div className="login-input-group">
              <label>Email Address</label>
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  clearError();
                }}
                required
              />
            </div>

            {!isCandidate && (
              <div className="login-input-group">
                <label>Company Name</label>
                <input
                  type="text"
                  placeholder="Enter your company name"
                  value={company}
                  onChange={(e) => {
                    setCompany(e.target.value);
                    clearError();
                  }}
                  required
                />
              </div>
            )}

            <div className="login-input-group">
              <label>Password</label>
              <input
                type="password"
                placeholder="Create a password (minimum 8 characters)"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  clearError();
                }}
                required
                minLength={8}
              />
            </div>

            <div className="login-input-group">
              <label>Confirm Password</label>
              <input
                type="password"
                placeholder="Confirm your password"
                value={confirmPassword}
                onChange={(e) => {
                  setConfirmPassword(e.target.value);
                  clearError();
                }}
                required
              />
            </div>

            {error && (
              <div className="register-error-message">
                <span className="register-error-icon">!</span>
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              className="login-submit-button"
              disabled={loading}
            >
              {loading ? "Creating Account..." : "Create Account"}
            </button>
          </form>

          <p className="login-register-text">
            Already have an account?{" "}
            <span onClick={() => navigate(`/${role}/login`)}>
              Login
            </span>
          </p>

          <button
            className="login-back-button"
            onClick={() => navigate("/")}
          >
            ← Back to Home
          </button>
        </div>
      )}
    </div>
  );
}

export default RegisterPage;