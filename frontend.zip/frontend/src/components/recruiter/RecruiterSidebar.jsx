import { NavLink, useNavigate } from "react-router-dom";
import { logoutUser } from "../../services/api";

function RecruiterSidebar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    logoutUser();
    navigate("/");
  };

  return (
    <aside className="recruiter-sidebar">
      <div className="sidebar-brand">
        <div className="brand-icon">✦</div>

        <div>
          <h2>HireAI</h2>
          <p>Recruiter Portal</p>
        </div>
      </div>

      <nav className="recruiter-navigation">
        <NavLink to="/recruiter" end className="sidebar-link">
          <span>▦</span>
          Dashboard
        </NavLink>

        <NavLink to="/recruiter/jobs" className="sidebar-link">
          <span>▤</span>
          Job Openings
        </NavLink>

        <NavLink to="/recruiter/applications" className="sidebar-link">
          <span>♙</span>
          Applications
        </NavLink>
      </nav>

      <div className="sidebar-footer">
        <div className="profile-avatar">HR</div>

        <div>
          <h4>Recruiter</h4>
          <p>Recruitment Team</p>
        </div>
      </div>

      {/* Logout Button */}
      <button className="recruiter-logout-button" onClick={handleLogout}>
        <span>↪</span>
        Logout
      </button>
    </aside>
  );
}

export default RecruiterSidebar;